# Findings

## Research question
Can we reproduce the pretrained F-LMM DeepSeekVL-1.3B grounding pipeline on RefCOCO, and what measurable limitation is worth testing?

## Current understanding
No results yet. Official paper and repo report a trained F-LMM checkpoint and RefCOCO evaluation; our environment has not been verified.

## Key results
**NONE — DO NOT ADD RESULTS WITHOUT LOGS.**

## Patterns and insights
Pending observations.

## Lessons and constraints
- Official repository warns `transformers` changes beyond 4.40 can affect reproduction.
- No claim about runtime/VRAM until measured on specific hardware.

## Open questions
- Which GPU is actually available? Does the complete model fit?
- Which files and loaders are required for evaluation?
- What is the official cIoU implementation and split?

## Experiment trajectory
No runs yet.
